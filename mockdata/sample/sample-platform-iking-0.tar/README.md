
# THIS FOLDER CONTAINS MOCK-DATA

## Data was generated using [faker](https://faker.readthedocs.io/en/master/)

## Any similarity to real-world data is purely due to chance
        